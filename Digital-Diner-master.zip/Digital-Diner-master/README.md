# Digital-Diner
A responsive restaurant website build using html and css. 
- This is a responsive restaurant website which helps the user to navigate quickly from one category of foods to another category of foods.
